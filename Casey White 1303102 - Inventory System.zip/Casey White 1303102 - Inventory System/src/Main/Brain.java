package Main;

import backbone.InHouse;
import backbone.Inventory;
import backbone.Outsourced;
import backbone.Product;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Brain extends Application {

    // Transfers control for the main screen
    public static Stage inventoryStage;

    @Override
    public void start(Stage primaryStage) throws Exception{
        addData();
        Parent root = FXMLLoader.load(getClass().getResource("/Controllers/Inventory.fxml"));
        primaryStage.setTitle("IMS");
        primaryStage.setScene(new Scene(root, 1000, 450));
        primaryStage.show();
        inventoryStage = primaryStage;
    }

    private void addData() {
        // Adds parts
        Inventory.addPart(new InHouse(1,"Part C2",2.04,20,1,20,20));
        Inventory.addPart(new Outsourced(2, "Part G1", 10.94, 9, 2, 5, "Staffing Inc."));
        Inventory.addPart(new InHouse(3,"Part L", 7.77, 3,1, 10, 93));
        Inventory.addPart(new InHouse(4, "Part LP", 4.19, 13, 4, 42, 15));
        Inventory.addPart(new Outsourced(5, "Part W24", 1.53, 4, 0, 10, "Direct Hire"));
        Inventory.addPart(new InHouse(6, "Part J1", 53.22, 4, 0, 14, 52));
        Inventory.addPart(new Outsourced(7, "Part P04", 7.43, 4, 0, 10, "Direct Hire"));

        // Add products
        Inventory.addProduct(new Product(1000, "Kern", 232.13, 4, 0, 100));
        Inventory.addProduct(new Product(1001, "Lamp", 30.23, 42, 2, 20));
        Inventory.addProduct(new Product(1002, "Driver", 4023.23, 1, 0, 100));

        Product temp1 = new Product(1003,"Phone", 10234.20, 1, 0, 1);
        temp1.addAssociatedPart(Inventory.lookupPart(4));
        Inventory.addProduct(temp1);

        Product temp2 = new Product(1004,"Shelf",202.11,1,0, 20);
        temp2.addAssociatedPart(Inventory.lookupPart(7));
        temp2.addAssociatedPart(Inventory.lookupPart(2));
        Inventory.addProduct(temp2);

        Product temp3 = new Product(1005,"Another Shelf", 20123.99,1000,20, 50);
        temp3.addAssociatedPart(Inventory.lookupPart(4));
        Inventory.addProduct(temp3);

    }

    public static void main(String[] args) {
        launch(args);
    }
}
