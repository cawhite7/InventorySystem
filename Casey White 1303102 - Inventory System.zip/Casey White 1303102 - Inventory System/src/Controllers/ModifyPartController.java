package Controllers;

import Main.Brain;
import backbone.InHouse;
import backbone.Inventory;
import backbone.Outsourced;
import backbone.Part;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;

import java.net.URL;
import java.util.ResourceBundle;

public class ModifyPartController implements Initializable {

    Part selectedPart = InventoryController.selectedPart;

    @FXML
    private RadioButton inHouseRadio;

    @FXML
    private RadioButton outsourcedRadio;

    @FXML
    private TextField modifyPartNameTextField;

    @FXML
    private TextField modifyPartInvTextField;

    @FXML
    private TextField modifyPartPriceTextField;

    @FXML
    private TextField modifyPartMaxTextField;

    @FXML
    private TextField modifyPartMinTextField;

    @FXML
    private TextField modifyPartMachIDTextField;

    @FXML
    private TextField modifyPartCompNmTextField;

    @FXML
    private Label modifyPartMachIDLabel;

    @FXML
    private Label modifyPartCompNmLabel;

    @FXML
    private TextField partID;

    @FXML
    void modifyPartCancelButtonClick() {
        InventoryController.ModifyPartStage.close();
        Brain.inventoryStage.show();
    }

    private boolean CheckForNull(TextField textfield) {
        return !modifyPartNameTextField.getText().isBlank() &&
                !modifyPartInvTextField.getText().isBlank() &&
                !modifyPartPriceTextField.getText().isBlank() &&
                !modifyPartMaxTextField.getText().isBlank() &&
                !modifyPartMinTextField.getText().isBlank() &&
                !textfield.getText().isBlank();
    }

    public void InHouseRadioClick() {
        modifyPartMachIDLabel.setVisible(true);
        modifyPartMachIDTextField.setVisible(true);
        modifyPartCompNmLabel.setVisible(false);
        modifyPartCompNmTextField.setVisible(false);
    }

    public void OutsourcedRadioClick() {
        modifyPartCompNmLabel.setVisible(true);
        modifyPartCompNmTextField.setVisible(true);
        modifyPartMachIDLabel.setVisible(false);
        modifyPartMachIDTextField.setVisible(false);
    }

    @FXML
    void modifyPartSaveButtonClick() {
        Part modPart;
        if (inHouseRadio.isSelected() && CheckForNull(modifyPartMachIDTextField)) {
            modPart = new InHouse(
                    Integer.parseInt(partID.getText()),
                    modifyPartNameTextField.getText(),
                    Double.parseDouble(modifyPartPriceTextField.getText()),
                    Integer.parseInt(modifyPartInvTextField.getText()),
                    Integer.parseInt(modifyPartMinTextField.getText()),
                    Integer.parseInt(modifyPartMaxTextField.getText()),
                    Integer.parseInt(modifyPartMachIDTextField.getText())
            );
            Inventory.updatePart(Inventory.getAllParts().indexOf(InventoryController.selectedPart), modPart);
            InventoryController.ModifyPartStage.close();
            Brain.inventoryStage.show();
        } else if (outsourcedRadio.isSelected() && CheckForNull(modifyPartCompNmTextField)) {
            modPart = new Outsourced(
                    Integer.parseInt(partID.getText()),
                    modifyPartNameTextField.getText(),
                    Double.parseDouble(modifyPartPriceTextField.getText()),
                    Integer.parseInt(modifyPartInvTextField.getText()),
                    Integer.parseInt(modifyPartMinTextField.getText()),
                    Integer.parseInt(modifyPartMaxTextField.getText()),
                    modifyPartCompNmTextField.getText()
            );
            Inventory.updatePart(Inventory.getAllParts().indexOf(InventoryController.selectedPart), modPart);
            InventoryController.ModifyPartStage.close();
            Brain.inventoryStage.show();
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Blanks");
            alter.setContentText("Please leave nothing blank");
            alter.show();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        partID.setText(Integer.toString(selectedPart.getId()));
        modifyPartNameTextField.setText(selectedPart.getName());
        modifyPartInvTextField.setText(Integer.toString(selectedPart.getStock()));
        modifyPartPriceTextField.setText(Double.toString(selectedPart.getPrice()));
        modifyPartMaxTextField.setText(Integer.toString(selectedPart.getMax()));
        modifyPartMinTextField.setText(Integer.toString(selectedPart.getMin()));
        if (selectedPart instanceof InHouse) {
            inHouseRadio.setSelected(true);
            modifyPartMachIDTextField.setText(Integer.toString(((InHouse) selectedPart).getMachineId()));
        }
        if (selectedPart instanceof Outsourced) {
            outsourcedRadio.setSelected(true);
            modifyPartCompNmLabel.setVisible(true);
            modifyPartCompNmTextField.setVisible(true);
            modifyPartMachIDLabel.setVisible(false);
            modifyPartMachIDTextField.setVisible(false);
            modifyPartCompNmTextField.setText(((Outsourced) selectedPart).getCompanyName());
        }
    }

    public void modifyPartNameCheck() {
        if (modifyPartNameTextField.getText().length() > 15) {
            modifyPartNameTextField.setText(modifyPartNameTextField.getText().substring(0, 15));
            modifyPartNameTextField.positionCaret(modifyPartNameTextField.getText().length());
        }
    }

    public void modifyPartInvCheck(KeyEvent keyEvent) {
        if (modifyPartInvTextField.getText().length() > 8) {
            modifyPartInvTextField.setText(modifyPartInvTextField.getText().substring(0, 8));
            modifyPartInvTextField.positionCaret(modifyPartInvTextField.getText().length());
        }
        if (!keyEvent.getCharacter().matches("^$|(\t|\b|\\d*)")) {
            modifyPartInvTextField.setText(Integer.toString(selectedPart.getStock()));
            modifyPartInvTextField.positionCaret(modifyPartNameTextField.getText().length());
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Numbers only");
            alter.setContentText("Please only input numbers");
            alter.show();
        }
    }

    public void modifyPartPriceCheck() {
        if (!modifyPartPriceTextField.getText().matches("^$|(\\b\\d{0,8}\\.\\d{1,2})|\\b\\d*\\.|\\b\\d*")) {
            modifyPartPriceTextField.setText(Double.toString(selectedPart.getPrice()));
            modifyPartPriceTextField.positionCaret(modifyPartPriceTextField.getText().length());
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Prices only");
            alter.setContentText("Please only input pricing (Ex. 20 or 20.02 or 20.2)");
            alter.show();
        }
    }


    public void modifyPartMaxCheck(KeyEvent keyEvent) {
        if (!keyEvent.getCharacter().matches("^$|(\t|\b|\\d*)")) {
            modifyPartMaxTextField.setText(Integer.toString(selectedPart.getMax()));
            modifyPartMaxTextField.positionCaret(modifyPartMaxTextField.getText().length());
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Numbers only");
            alter.setContentText("Please only input numbers");
            alter.show();
        } else {
            if (!modifyPartMaxTextField.getText().isBlank() && Integer.parseInt(modifyPartMaxTextField.getText()) > 20000) {
                modifyPartMaxTextField.setText(Integer.toString(selectedPart.getMax()));
                modifyPartMaxTextField.positionCaret(modifyPartMaxTextField.getText().length());
                Alert alter = new Alert(Alert.AlertType.WARNING);
                alter.setHeaderText("Over Limit");
                alter.setContentText("Max Value 20000");
                alter.show();
            }
        }
    }

    public void modifyPartMinCheck(KeyEvent keyEvent) {
        if (!keyEvent.getCharacter().matches("^$|(\t|\b|\\d*)")) {
            modifyPartMinTextField.setText(Integer.toString(selectedPart.getMin()));
            modifyPartMinTextField.positionCaret(modifyPartMinTextField.getText().length());
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Numbers only");
            alter.setContentText("Please only input numbers");
            alter.show();
        } else if ((!modifyPartMinTextField.getText().isBlank() && !modifyPartMaxTextField.getText().isBlank())
                && Integer.parseInt(modifyPartMinTextField.getText()) > Integer.parseInt(modifyPartMaxTextField.getText())) {
            modifyPartMinTextField.setText(Integer.toString(selectedPart.getMax()));
            modifyPartMinTextField.positionCaret(modifyPartMinTextField.getText().length());
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Too High");
            alter.setContentText("Min can not be higher than Max");
            alter.show();
        }
    }

    public void modifyPartMachIDCheck(KeyEvent keyEvent) {
        if (!keyEvent.getCharacter().matches("^$|(\t|\b|\\d*)")) {
            modifyPartMachIDTextField.setText(Integer.toString(((InHouse) selectedPart).getMachineId()));
            modifyPartMachIDTextField.positionCaret(modifyPartMachIDTextField.getText().length());
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Numbers only");
            alter.setContentText("Please only input numbers");
            alter.show();
        } else if (!modifyPartMachIDTextField.getText().isBlank() && Integer.parseInt(modifyPartMachIDTextField.getText()) > 500000) {
            modifyPartMachIDTextField.setText(Integer.toString(((InHouse) selectedPart).getMachineId()));
            modifyPartMachIDTextField.positionCaret(modifyPartMachIDTextField.getText().length());
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Too High");
            alter.setContentText("Can not be above 500000");
            alter.show();
        }
    }

    public void modifyPartCompNmCheck() {
        if (modifyPartCompNmTextField.getText().length() > 15) {
            modifyPartCompNmTextField.setText(modifyPartCompNmTextField.getText().substring(0, 15));
            modifyPartCompNmTextField.positionCaret(modifyPartCompNmTextField.getText().length());
        }
    }
}
