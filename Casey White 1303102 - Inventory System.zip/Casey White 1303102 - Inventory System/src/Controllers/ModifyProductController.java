package Controllers;

import Main.Brain;
import backbone.*;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;

import java.net.URL;
import java.util.ResourceBundle;

public class ModifyProductController implements Initializable {

    @FXML
    public TextField ModifyProductID;

    @FXML
    private TextField ModifyProductNameTextField;

    @FXML
    private TextField ModifyProductInvTextField;

    @FXML
    private TextField ModifyProductPriceTextField;

    @FXML
    private TextField ModifyProductMaxTextField;

    @FXML
    private TextField ModifyProductMinTextField;

    @FXML
    private TableView<Part> ModifyProductAssocTable;

    @FXML
    private TableView<Part> ModifyProductDassocTable;

    @FXML
    private TextField ModifyProductSearchTextField;

    private final ObservableList<Part> tempAssocList = InventoryController.selectedProduct.getAllAssociatedParts();

    @FXML
    void ModifyProductAddButtonClick() {
        tempAssocList.add(ModifyProductDassocTable.getSelectionModel().getSelectedItem());
        ModifyProductAssocTable.setItems(tempAssocList);
    }

    @FXML
    void ModifyProductCancelButtonClick() {
        InventoryController.ModifyProductStage.hide();
        Brain.inventoryStage.show();
    }

    @FXML
    void ModifyProductDeleteButtonClick() {
        tempAssocList.remove(ModifyProductAssocTable.getSelectionModel().getSelectedItem());
    }

    @FXML
    void ModifyProductInvCheck(KeyEvent event) {
        if (ModifyProductInvTextField.getText().length() > 8) {
            ModifyProductInvTextField.setText(ModifyProductInvTextField.getText().substring(0, 8));
            ModifyProductInvTextField.positionCaret(ModifyProductInvTextField.getText().length());
        }
        if (!event.getCharacter().matches("^$|(\t|\b|\\d*)")) {
            ModifyProductInvTextField.clear();
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Numbers only");
            alter.setContentText("Please only input numbers");
            alter.show();
        }
    }

    @FXML
    void ModifyProductMaxCheck(KeyEvent event) {
        if (!event.getCharacter().matches("^$|(\t|\b|\\d*)")) {
            ModifyProductMaxTextField.clear();
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Numbers only");
            alter.setContentText("Please only input numbers");
            alter.show();
        } else {
            if (!ModifyProductMaxTextField.getText().isBlank() && Integer.parseInt(ModifyProductMaxTextField.getText()) > 20000) {
                ModifyProductMaxTextField.clear();
                Alert alter = new Alert(Alert.AlertType.WARNING);
                alter.setHeaderText("Over Limit");
                alter.setContentText("Max Value 20000");
                alter.show();
            }
        }
    }

    @FXML
    void ModifyProductMinCheck(KeyEvent event) {
        if (!event.getCharacter().matches("^$|(\t|\b|\\d*)")) {
            ModifyProductMinTextField.clear();
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Numbers only");
            alter.setContentText("Please only input numbers");
            alter.show();
        } else if ((!ModifyProductMaxTextField.getText().isBlank() && !ModifyProductMinTextField.getText().isBlank()) && Integer.parseInt(ModifyProductMinTextField.getText()) > Integer.parseInt(ModifyProductMaxTextField.getText())) {
            ModifyProductMinTextField.clear();
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Too High");
            alter.setContentText("Min can not be higher than Max");
            alter.show();
        }
    }

    @FXML
    void ModifyProductNameCheck() {
        if (ModifyProductNameTextField.getText().length() > 15) {
            ModifyProductNameTextField.setText(ModifyProductNameTextField.getText().substring(0, 15));
            ModifyProductNameTextField.positionCaret(ModifyProductNameTextField.getText().length());
        }
    }

    @FXML
    void ModifyProductPriceCheck() {
        if (!ModifyProductPriceTextField.getText().matches("^$|(\\b\\d{0,8}\\.\\d{1,2})|\\b\\d*\\.|\\b\\d*")) {
            ModifyProductPriceTextField.clear();
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Prices only");
            alter.setContentText("Please only input pricing (Ex. 20 or 20.02 or 20.2)");
            alter.show();
        }
    }

    private boolean CheckForNull() {
        return !ModifyProductNameTextField.getText().isBlank() &&
                !ModifyProductInvTextField.getText().isBlank() &&
                !ModifyProductPriceTextField.getText().isBlank() &&
                !ModifyProductMaxTextField.getText().isBlank() &&
                !ModifyProductMinTextField.getText().isBlank();
    }

    @FXML
    void ModifyProductSaveButtonClick() {
        if (CheckForNull()) {
            Product addProd = new Product(
                    InventoryController.selectedProduct.getId(),
                    ModifyProductNameTextField.getText(),
                    Double.parseDouble(ModifyProductPriceTextField.getText()),
                    Integer.parseInt(ModifyProductInvTextField.getText()),
                    Integer.parseInt(ModifyProductMinTextField.getText()),
                    Integer.parseInt(ModifyProductMaxTextField.getText())
            );
            for (Part part : tempAssocList) {
                addProd.addAssociatedPart(part);
            }
            int getIndex = Inventory.getAllProducts().indexOf(InventoryController.selectedProduct);
            Inventory.updateProduct(getIndex, addProd);
            InventoryController.ModifyProductStage.close();
            Brain.inventoryStage.show();
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Blanks");
            alter.setContentText("Please leave nothing blank");
            alter.show();
        }
    }

    @FXML
    void ModifyProductSearchButtonClick() {
        ModifyProductDassocTable.setItems(Inventory.lookupPart(ModifyProductSearchTextField.getText()));
    }

    public void setProductTable() {
        ModifyProductDassocTable.setItems(Inventory.getAllParts());
        ModifyProductAssocTable.setItems(InventoryController.selectedProduct.getAllAssociatedParts());
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setProductTable();
        ModifyProductID.setText(Integer.toString(InventoryController.selectedProduct.getId()));
        ModifyProductNameTextField.setText(InventoryController.selectedProduct.getName());
        ModifyProductInvTextField.setText(Integer.toString(InventoryController.selectedProduct.getStock()));
        ModifyProductPriceTextField.setText(Double.toString(InventoryController.selectedProduct.getPrice()));
        ModifyProductMinTextField.setText(Integer.toString(InventoryController.selectedProduct.getMin()));
        ModifyProductMaxTextField.setText(Integer.toString(InventoryController.selectedProduct.getMax()));
    }
}
