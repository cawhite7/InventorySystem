package Controllers;

import Main.Brain;
import backbone.InHouse;
import backbone.Inventory;
import backbone.Outsourced;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;

public class AddPartController {

    private static int i = 8;

    @FXML
    public Button AddPartSaveButton;

    @FXML
    private RadioButton inHouseRadio;

    @FXML
    private RadioButton outsourcedRadio;

    @FXML
    private TextField AddPartNameTextField;

    @FXML
    private TextField AddPartInvTextField;

    @FXML
    private TextField AddPartPriceTextField;

    @FXML
    private TextField AddPartMaxTextField;

    @FXML
    private TextField AddPartMinTextField;

    @FXML
    private TextField AddPartMachIDTextField;

    @FXML
    private TextField AddPartCompNmTextField;

    @FXML
    private Label AddPartMachIDLabel;

    @FXML
    private Label AddPartCompNmLabel;

    @FXML
    void AddPartCancelButtonClick() {
        InventoryController.AddPartStage.close();
        Brain.inventoryStage.show();
    }

    private boolean CheckForNull(TextField textfield) {
        return !AddPartNameTextField.getText().isBlank() &&
                !AddPartInvTextField.getText().isBlank() &&
                !AddPartPriceTextField.getText().isBlank() &&
                !AddPartMaxTextField.getText().isBlank() &&
                !AddPartMinTextField.getText().isBlank() &&
                !textfield.getText().isBlank();
    }

    @FXML
    void AddPartSaveButtonClick() {
        if (inHouseRadio.isSelected() && CheckForNull(AddPartMachIDTextField)) {
            Inventory.addPart(new InHouse(
                    i,
                    AddPartNameTextField.getText(),
                    Double.parseDouble(AddPartPriceTextField.getText()),
                    Integer.parseInt(AddPartInvTextField.getText()),
                    Integer.parseInt(AddPartMinTextField.getText()),
                    Integer.parseInt(AddPartMaxTextField.getText()),
                    Integer.parseInt(AddPartMachIDTextField.getText())
            ));
            i += 1;
            InventoryController.AddPartStage.close();
            Brain.inventoryStage.show();
        } else if (outsourcedRadio.isSelected() && CheckForNull(AddPartCompNmTextField)) {
            Inventory.addPart(new Outsourced(
                    i,
                    AddPartNameTextField.getText(),
                    Double.parseDouble(AddPartPriceTextField.getText()),
                    Integer.parseInt(AddPartInvTextField.getText()),
                    Integer.parseInt(AddPartMinTextField.getText()),
                    Integer.parseInt(AddPartMaxTextField.getText()),
                    AddPartCompNmTextField.getText()
            ));
            i += 1;
            InventoryController.AddPartStage.close();
            Brain.inventoryStage.show();
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Blanks");
            alter.setContentText("Please leave nothing blank");
            alter.show();
        }
    }

    public void InHouseRadioClick() {
        AddPartMachIDLabel.setVisible(true);
        AddPartMachIDTextField.setVisible(true);
        AddPartCompNmLabel.setVisible(false);
        AddPartCompNmTextField.setVisible(false);
    }

    public void OutsourcedRadioClick() {
        AddPartCompNmLabel.setVisible(true);
        AddPartCompNmTextField.setVisible(true);
        AddPartMachIDLabel.setVisible(false);
        AddPartMachIDTextField.setVisible(false);
    }


    public void AddPartNameCheck() {
        if (AddPartNameTextField.getText().length() > 15) {
            AddPartNameTextField.setText(AddPartNameTextField.getText().substring(0, 15));
            AddPartNameTextField.positionCaret(AddPartNameTextField.getText().length());
        }
    }

    public void AddPartInvCheck(KeyEvent keyEvent) {
        if (AddPartInvTextField.getText().length() > 8) {
            AddPartInvTextField.setText(AddPartInvTextField.getText().substring(0, 8));
            AddPartInvTextField.positionCaret(AddPartInvTextField.getText().length());
        }
        if (!keyEvent.getCharacter().matches("^$|(\t|\b|\\d*)")) {
            AddPartInvTextField.clear();
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Numbers only");
            alter.setContentText("Please only input numbers");
            alter.show();
        }
    }

    public void AddPartPriceCheck() {
        if (!AddPartPriceTextField.getText().matches("^$|(\\b\\d{0,8}\\.\\d{1,2})|\\b\\d*\\.|\\b\\d*")) {
            AddPartPriceTextField.clear();
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Prices only");
            alter.setContentText("Please only input pricing (Ex. 20 or 20.02 or 20.2)");
            alter.show();
        }
    }


    public void AddPartMaxCheck(KeyEvent keyEvent) {
        if (!keyEvent.getCharacter().matches("^$|(\t|\b|\\d*)")) {
            AddPartMaxTextField.clear();
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Numbers only");
            alter.setContentText("Please only input numbers");
            alter.show();
        } else {
            if (!AddPartMaxTextField.getText().isBlank() && Integer.parseInt(AddPartMaxTextField.getText()) > 20000) {
                AddPartMaxTextField.clear();
                Alert alter = new Alert(Alert.AlertType.WARNING);
                alter.setHeaderText("Over Limit");
                alter.setContentText("Max Value 20000");
                alter.show();
            }
        }
    }

    public void AddPartMinCheck(KeyEvent keyEvent) {
        if (!keyEvent.getCharacter().matches("^$|(\t|\b|\\d*)")) {
            AddPartMinTextField.clear();
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Numbers only");
            alter.setContentText("Please only input numbers");
            alter.show();
        } else if ((!AddPartMinTextField.getText().isBlank() && !AddPartMaxTextField.getText().isBlank()) && Integer.parseInt(AddPartMinTextField.getText()) > Integer.parseInt(AddPartMaxTextField.getText())) {
            AddPartMinTextField.clear();
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Too High");
            alter.setContentText("Min can not be higher than Max");
            alter.show();
        }
    }

    public void AddPartMachIDCheck(KeyEvent keyEvent) {
        if (!keyEvent.getCharacter().matches("^$|(\t|\b|\\d*)")) {
            AddPartMachIDTextField.clear();
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Numbers only");
            alter.setContentText("Please only input numbers");
            alter.show();
        } else if (!AddPartMachIDTextField.getText().isBlank() && Integer.parseInt(AddPartMachIDTextField.getText()) > 500000) {
            AddPartMachIDTextField.clear();
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Too High");
            alter.setContentText("Can not be above 500000");
            alter.show();
        }
    }

    public void AddPartCompNmCheck() {
        if (AddPartCompNmTextField.getText().length() > 15) {
            AddPartCompNmTextField.setText(AddPartCompNmTextField.getText().substring(0, 15));
            AddPartCompNmTextField.positionCaret(AddPartCompNmTextField.getText().length());
        }
    }
}
