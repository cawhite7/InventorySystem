package Controllers;

import Main.Brain;
import backbone.Inventory;
import backbone.Part;
import backbone.Product;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class InventoryController implements Initializable {

    public static Stage AddPartStage = new Stage();
    public static Stage AddProductStage = new Stage();
    public static Stage ModifyPartStage = new Stage();
    public static Stage ModifyProductStage = new Stage();
    public static Part selectedPart;
    public static Product selectedProduct;

    @FXML
    private TableView<Part> PartsTable;
    @FXML
    private TableView<Product> ProductsTable;

    @FXML
    private TextField PartsSearchTextField;

    @FXML
    private TextField ProductsSearchTextField;

    @FXML
    private Label IMSLabel;

    public void tables() {
        PartsTable.setItems(Inventory.getAllParts());
        ProductsTable.setItems(Inventory.getAllProducts());
    }

    @FXML
    void AddPartButtonClick() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Controllers/AddPart.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root, 400, 450);
        AddPartStage.setScene(scene);
        AddPartStage.setTitle("Add Part");
        Brain.inventoryStage.hide();
        AddPartStage.show();
    }

    @FXML
    void AddProductsButtonClick() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Controllers/AddProduct.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root, 1000, 600);
        AddProductStage.setScene(scene);
        AddProductStage.setTitle("Add Product");
        Brain.inventoryStage.hide();
        AddProductStage.show();
    }

    @FXML
    void DeletePartsButtonClick() {
        if (selectedPart != null) {
            Inventory.deletePart(selectedPart);
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Nothing selected");
            alter.setContentText("Please select the part you would like to delete");
            alter.show();
        }
    }

    @FXML
    void DeleteProductsButtonClick() {
        if (selectedProduct != null) {
            Inventory.deleteProduct(selectedProduct);
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Nothing selected");
            alter.setContentText("Please select the product you would like to delete");
            alter.show();
        }
    }

    @FXML
    void InventoryExitButtonClick() {
        Brain.inventoryStage.close();
    }

    @FXML
    void PartsTableClick() {
        selectedPart = PartsTable.getSelectionModel().getSelectedItem();
    }

    @FXML
    void ProductsTableClick() {
        selectedProduct = ProductsTable.getSelectionModel().getSelectedItem();
    }

    @FXML
    void ModifyPartsButtonClick() throws IOException {
        if (selectedPart != null) {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Controllers/ModifyPart.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root, 400, 450);
            ModifyPartStage.setScene(scene);
            ModifyPartStage.setTitle("Modify Part");
            Brain.inventoryStage.hide();
            ModifyPartStage.show();
        }
    }

    @FXML
    void ModifyProductsButtonClick() throws IOException {
        if (selectedProduct != null) {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Controllers/ModifyProduct.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root, 1000,600);
            ModifyProductStage.setScene(scene);
            ModifyProductStage.setTitle("Modify Product");
            Brain.inventoryStage.hide();
            ModifyProductStage.show();
        }
    }

    @FXML
    void PartsSearchButtonClick() {
        PartsTable.setItems(Inventory.lookupPart(PartsSearchTextField.getText()));
    }

    @FXML
    void ProductsSearchButtonClick() {
        ProductsTable.setItems(Inventory.lookupProduct(ProductsSearchTextField.getText()));
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        tables();
    }

    private int count = 0;

    public void IMSLabelEnter() {
        if (count == 0) {
            IMSLabel.setLayoutX(300);
            IMSLabel.setText("\"Can't Touch This!\" - MC Hammer");
            count += 1;
        } else {
            IMSLabel.setLayoutX(30);
            IMSLabel.setText("Inventory Management System");
            count -= 1;
        }
    }
}
