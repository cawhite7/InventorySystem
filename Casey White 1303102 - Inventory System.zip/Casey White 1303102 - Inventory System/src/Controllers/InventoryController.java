package Controllers;

public class InventoryController {
}
