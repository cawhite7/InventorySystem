package Controllers;

import Main.Brain;
import backbone.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;

import java.net.URL;
import java.util.ResourceBundle;

public class AddProductController implements Initializable {

    private static int p = 1006;

    @FXML
    private TextField AddProductNameTextField;

    @FXML
    private TextField AddProductInvTextField;

    @FXML
    private TextField AddProductPriceTextField;

    @FXML
    private TextField AddProductMaxTextField;

    @FXML
    private TextField AddProductMinTextField;

    @FXML
    private TableView<Part> AddProductAssocTable;

    @FXML
    private TableView<Part> AddProductDassocTable;

    @FXML
    private TextField AddProductSearchTextField;

    private final ObservableList<Part> tempAssocList = FXCollections.observableArrayList();

    @FXML
    void AddProductAddButtonClick() {
        tempAssocList.add(AddProductDassocTable.getSelectionModel().getSelectedItem());
        AddProductAssocTable.setItems(tempAssocList);
    }

    @FXML
    void AddProductCancelButtonClick() {
        InventoryController.AddProductStage.hide();
        Brain.inventoryStage.show();
    }

    @FXML
    void AddProductDeleteButtonClick() {
        tempAssocList.remove(AddProductAssocTable.getSelectionModel().getSelectedItem());
    }

    @FXML
    void AddProductInvCheck(KeyEvent event) {
        if (AddProductInvTextField.getText().length() > 8) {
            AddProductInvTextField.setText(AddProductInvTextField.getText().substring(0, 8));
            AddProductInvTextField.positionCaret(AddProductInvTextField.getText().length());
        }
        if (!event.getCharacter().matches("^$|(\t|\b|\\d*)")) {
            AddProductInvTextField.clear();
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Numbers only");
            alter.setContentText("Please only input numbers");
            alter.show();
        }
    }

    @FXML
    void AddProductMaxCheck(KeyEvent event) {
        if (!event.getCharacter().matches("^$|(\t|\b|\\d*)")) {
            AddProductMaxTextField.clear();
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Numbers only");
            alter.setContentText("Please only input numbers");
            alter.show();
        } else {
            if (!AddProductMaxTextField.getText().isBlank() && Integer.parseInt(AddProductMaxTextField.getText()) > 20000) {
                AddProductMaxTextField.clear();
                Alert alter = new Alert(Alert.AlertType.WARNING);
                alter.setHeaderText("Over Limit");
                alter.setContentText("Max Value 20000");
                alter.show();
            }
        }
    }

    @FXML
    void AddProductMinCheck(KeyEvent event) {
        if (!event.getCharacter().matches("^$|(\t|\b|\\d*)")) {
            AddProductMinTextField.clear();
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Numbers only");
            alter.setContentText("Please only input numbers");
            alter.show();
        } else if ((!AddProductMaxTextField.getText().isBlank() && !AddProductMinTextField.getText().isBlank()) && Integer.parseInt(AddProductMinTextField.getText()) > Integer.parseInt(AddProductMaxTextField.getText())) {
            AddProductMinTextField.clear();
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Too High");
            alter.setContentText("Min can not be higher than Max");
            alter.show();
        }
    }

    @FXML
    void AddProductNameCheck() {
        if (AddProductNameTextField.getText().length() > 15) {
            AddProductNameTextField.setText(AddProductNameTextField.getText().substring(0, 15));
            AddProductNameTextField.positionCaret(AddProductNameTextField.getText().length());
        }
    }

    @FXML
    void AddProductPriceCheck() {
        if (!AddProductPriceTextField.getText().matches("^$|(\\b\\d{0,8}\\.\\d{1,2})|\\b\\d*\\.|\\b\\d*")) {
            AddProductPriceTextField.clear();
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Prices only");
            alter.setContentText("Please only input pricing (Ex. 20 or 20.02 or 20.2)");
            alter.show();
        }
    }

    private boolean CheckForNull() {
        return !AddProductNameTextField.getText().isBlank() &&
                !AddProductInvTextField.getText().isBlank() &&
                !AddProductPriceTextField.getText().isBlank() &&
                !AddProductMaxTextField.getText().isBlank() &&
                !AddProductMinTextField.getText().isBlank();
    }

    @FXML
    void AddProductSaveButtonClick() {
        if (CheckForNull()) {
            Product addProd = new Product(
                    p,
                    AddProductNameTextField.getText(),
                    Double.parseDouble(AddProductPriceTextField.getText()),
                    Integer.parseInt(AddProductInvTextField.getText()),
                    Integer.parseInt(AddProductMinTextField.getText()),
                    Integer.parseInt(AddProductMaxTextField.getText())
            );
            for (Part part : tempAssocList) {
                addProd.addAssociatedPart(part);
            }
            Inventory.addProduct(addProd);
            p += 1;
            InventoryController.AddProductStage.close();
            Brain.inventoryStage.show();
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Blanks");
            alter.setContentText("Please leave nothing blank");
            alter.show();
        }
    }

    @FXML
    void AddProductSearchButtonClick() {
        AddProductDassocTable.setItems(Inventory.lookupPart(AddProductSearchTextField.getText()));
    }

    public void setProductTable() {
        AddProductDassocTable.setItems(Inventory.getAllParts());
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setProductTable();
    }
}
